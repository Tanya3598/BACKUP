declare module "@salesforce/apex/ChatBotCopyTextUpdateController.getCoptTexts" {
  export default function getCoptTexts(param: {locale: any}): Promise<any>;
}
