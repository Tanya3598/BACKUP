declare module "@salesforce/apex/CaseRedactController.fetchCase" {
  export default function fetchCase(param: {caseId: any}): Promise<any>;
}
declare module "@salesforce/apex/CaseRedactController.fetchCaseComments" {
  export default function fetchCaseComments(param: {caseId: any}): Promise<any>;
}
declare module "@salesforce/apex/CaseRedactController.updateCase" {
  export default function updateCase(param: {caseId: any, redactDescription: any}): Promise<any>;
}
declare module "@salesforce/apex/CaseRedactController.updateCaseComments" {
  export default function updateCaseComments(param: {commentId: any, redactComment: any}): Promise<any>;
}
declare module "@salesforce/apex/CaseRedactController.fetchChat" {
  export default function fetchChat(param: {chatId: any}): Promise<any>;
}
declare module "@salesforce/apex/CaseRedactController.updateChat" {
  export default function updateChat(param: {chatId: any, redactBody: any}): Promise<any>;
}
