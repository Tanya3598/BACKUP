declare module "@salesforce/apex/PersonAccountLeadUtility.fetchLatestRecordID" {
  export default function fetchLatestRecordID(param: {recordId: any}): Promise<any>;
}
