declare module "@salesforce/apex/CaseAnonymisationController.scheduleJob" {
  export default function scheduleJob(param: {cronString: any, retentionPolicy: any}): Promise<any>;
}
